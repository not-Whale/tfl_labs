def delete_spaces(input_rule):
    return input_rule.replace(' ', '').replace('\t', '').replace('\r', '').replace('\n', '')

